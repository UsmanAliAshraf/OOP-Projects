﻿using LibraryFiles.BL;
using LibraryFiles.Utilities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryFiles.DL
{
    public class CitizenDBCRUD: ICitizenCRUD
    {
        private static List<citizen> dataList = new List<citizen>();
        public static List<citizen> GetDataList() 
        {             
            return dataList;
        }
        public void StoreUser(List<citizen> dataList)
        {
            string connectionString =FilePath.GetConnectionString();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO CitizenData (Name, LastName, Gender, City, Cnic, FatherName, Province, TemporaryAdress, PermanentAdress, VaccineName, VaccineDose, Date,Month,Year, Income,TotalWorth, Age, TokenNumber) VALUES (@Name, @LastName, @Gender, @City, @Cnic, @FatherName, @Province, @TemporaryAdress, @PermanentAdress, @VaccineName, @VaccineDose, @Date, @Month, @Year, @Income, @TotalWorth, @Age, @TokenNumber)";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();

                foreach (var citizen in dataList)
                {
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@Name", citizen.Name);
                    command.Parameters.AddWithValue("@LastName", citizen.LastName);
                    command.Parameters.AddWithValue("@Gender", citizen.Gender);
                    command.Parameters.AddWithValue("@City", citizen.City);
                    command.Parameters.AddWithValue("@Cnic", citizen.Cnic);
                    command.Parameters.AddWithValue("@FatherName", citizen.FatherName);
                    command.Parameters.AddWithValue("@Province", citizen.Province);
                    command.Parameters.AddWithValue("@TemporaryAdress", citizen.Temp_adress);
                    command.Parameters.AddWithValue("@PermanentAdress", citizen.PermanentAdress);
                    command.Parameters.AddWithValue("@VaccineName", citizen.VaccineName);
                    command.Parameters.AddWithValue("@VaccineDose", citizen.Dose);
                    command.Parameters.AddWithValue("@Date", citizen.Date);
                    command.Parameters.AddWithValue("@Month", citizen.Month);
                    command.Parameters.AddWithValue("@Year", citizen.Year);
                    command.Parameters.AddWithValue("@Income", citizen.Income);
                    command.Parameters.AddWithValue("@TotalWorth", citizen.WorthTotal);
                    command.Parameters.AddWithValue("@Age", citizen.Age);
                    command.Parameters.AddWithValue("@TokenNumber", citizen.TokenNumber);
                    command.ExecuteNonQuery();
                }
            }
        }

        public void deleteUserFromList(citizen user, List<citizen> person)
        {           
        }

        public citizen isCitizenExist(string cnic)
        {
            return null;
        }

        public void load(string path)
        {
        }
    }
}
